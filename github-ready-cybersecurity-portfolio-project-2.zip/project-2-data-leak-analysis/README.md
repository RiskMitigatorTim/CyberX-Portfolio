# 📁 Portfolio Project #2: Data Leak Risk Analysis & Least Privilege Control

## 🎯 Goal
To analyze a data leak incident and apply NIST SP 800-53 AC-6 (Least Privilege) controls to prevent future risks.

## 🧰 Tools & Frameworks Used
- NIST SP 800-53 – Access Control (AC-6)
- NIST Cybersecurity Framework (CSF)
- Policy writing & incident analysis

## 🧾 Incident Summary
A sales manager shared internal-only documents with their team, including unreleased product files and customer data. The access was not revoked post-meeting. A team member later shared the folder link with an external partner, who posted it publicly.

## 🔐 Control Applied: NIST SP 800-53 – AC-6: Least Privilege

| Enhancement                 | Implementation Example                          |
|----------------------------|--------------------------------------------------|
| Auto-expiring permissions  | 24–48 hour shared link expiration               |
| Role-based access          | Managers only can share sensitive folders       |
| Logging user activity      | Enable audit trails for shared link usage       |
| Regular access audits      | Monthly review of shared files & permissions    |

## ✅ Recommendations
- Implement time-based expiration for shared links
- Conduct quarterly audits of file sharing privileges
- Create role-based access templates
- Publish internal quick guides on data sharing best practices

## 📘 What I Learned
- How to apply NIST controls to a real-world scenario
- Importance of least privilege and audit trails
- How to document and communicate technical risk clearly
