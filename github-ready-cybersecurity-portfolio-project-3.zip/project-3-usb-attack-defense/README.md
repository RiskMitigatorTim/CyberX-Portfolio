# 📁 Portfolio Project #3: USB Drop Attack Simulation & Defense Strategy

## 🎯 Goal
To analyze the risk of a compromised USB device found on premises and develop a multi-layered cybersecurity defense strategy.

## 🧰 Tools & Concepts Used
- NIST SP 800-53 controls: SC (System Protection), AT (Awareness Training)
- Threat modeling using CIA triad and attacker mindset
- Endpoint protection and USB control tools
- Security awareness training techniques

## 🧾 Scenario Summary
An employee finds a USB drive in the hospital parking lot and inserts it into a work computer. The USB contains both sensitive work documents and personal family photos. This creates an opportunity for attackers to exploit the mixed data for blackmail, malware injection, or social engineering.

## ⚠️ Risk Analysis

| Control Type   | Examples                                                                 |
|----------------|--------------------------------------------------------------------------|
| Technical      | USB port control, endpoint protection, auto-sandboxing, device whitelisting |
| Operational    | Cybersecurity awareness training, BYOD policies, phishing simulations    |
| Managerial     | Data classification policies, encryption mandates, incident response plan |

## ✅ Recommendations
- Disable USB ports or use device whitelisting
- Use sandbox environments for scanning untrusted media
- Train employees on USB safety and social engineering
- Classify and encrypt all sensitive files
- Establish incident response protocol for unknown media

## 📘 What I Learned
- Human behavior can be the weakest link in cybersecurity
- USB attacks are simple but can trigger serious breaches
- Layered defense using training, policy, and tools is essential
