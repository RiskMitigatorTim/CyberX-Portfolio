# 📁 Portfolio Project #1: Phishing Click Rate Analysis

## 🎯 Goal
To identify departments most vulnerable to phishing attacks and propose targeted security awareness training.

## 🧰 Tools Used
- Excel for data analysis  
- Python (matplotlib, seaborn) for visualization  
- NIST 800-53 / CIS Controls for compliance mapping  

## 📊 Data Summary

| Department                | Clicked Phishing Emails |
|---------------------------|--------------------------|
| Media Relations           | 40                       |
| Human Resources           | 30                       |
| Professional Development  | 27                       |
| Customer Service          | 18                       |
| Global Security           | 10                       |

## 📈 Visualization

![Phishing Chart](phishing_clicks_chart.png)

## 📖 Description
- Analyzed phishing simulation results across 5 departments.
- Identified Media Relations and HR as high-risk based on click rates.
- Proposed department-specific security awareness training and quarterly simulations.
- Suggested tracking KPIs (e.g., reduced click rate).
- Mapped recommendations to NIST SP 800-53 (AT-2, AT-3) and CIS Control 14.

## 📘 What I Learned
- How to assess human risk factors in cybersecurity.
- How to interpret data for actionable security improvements.
- Importance of tailoring training efforts to specific business units.
